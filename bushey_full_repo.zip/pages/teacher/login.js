import { supabase } from '../../lib/supabaseClient';
import { useState } from 'react';

export default function Login(){
 const[email,setEmail]=useState('');
 const[password,setPassword]=useState('');
 async function login(){
   const { error } = await supabase.auth.signInWithPassword({email,password});
   if(error) alert(error.message); else window.location='/teacher/dashboard';
 }
 return (<div><h1>Teacher Login</h1>
 <input value={email} onChange={e=>setEmail(e.target.value)} placeholder='Email'/>
 <input value={password} onChange={e=>setPassword(e.target.value)} type='password' placeholder='Password'/>
 <button onClick={login}>Login</button></div>);
}