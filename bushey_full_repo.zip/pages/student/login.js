import { useState } from 'react';
export default function StudentLogin(){
 const[pin,setPin]=useState('');
 function go(){window.location='/student/test?pin='+pin;}
 return(<div><h1>Student Login</h1><input value={pin} onChange={e=>setPin(e.target.value)} /><button onClick={go}>Go</button></div>);
}